import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { COOKIE_NAME, cookieValido } from "./lib/admin-gate";

export async function middleware(req: NextRequest) {
  let res = NextResponse.next({ request: req });
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll: () => req.cookies.getAll(),
        setAll: (list) => {
          list.forEach(({ name, value }) => req.cookies.set(name, value));
          res = NextResponse.next({ request: req });
          list.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
        },
      },
    }
  );
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
  if (req.nextUrl.pathname.startsWith("/admin")) {
    const ok = await cookieValido(req.cookies.get(COOKIE_NAME)?.value, user.id, process.env.ADMIN_ACCESS_KEY);
    if (!ok) {
      const url = req.nextUrl.clone();
      url.pathname = "/acesso-restrito";
      url.search = "";
      return NextResponse.redirect(url);
    }
  }
  return res;
}
export const config = { matcher: ["/admin/:path*", "/conta/:path*", "/acesso-restrito"] };
