"use server";
import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import { adminClient } from "../../../lib/supabase/admin";
import { criarPix } from "../../../lib/payments/mercadopago";
import { pagamentoConfigurado } from "../../../lib/payments/config";

export async function iniciarPagamento(fd: FormData) {
  const slug = String(fd.get("slug") ?? "");
  const volta = (msg: string): never => redirect(`/campanhas/${slug}?erro=${encodeURIComponent(msg)}`);
  let nums: unknown;
  try { nums = JSON.parse(String(fd.get("numbers") ?? "[]")); } catch { nums = null; }
  if (!Array.isArray(nums) || !nums.length || !nums.every((n) => Number.isInteger(n))) volta("Escolha pelo menos um número.");

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const auto = pagamentoConfigurado();                                   // PIX automático (provedor + webhook)
  const manual = !auto && !!(await supabase.rpc("pix_manual_ativo")).data; // PIX direto na chave do dono, conferido por ele
  if (!auto && !manual) volta("O pagamento ainda não foi configurado. Nenhum número foi reservado.");

  // 1) o banco confere disponibilidade, limites, cupom e preço, e reserva (valor sempre calculado no servidor)
  const { data, error } = await supabase.rpc("reserve_numbers", {
    p_campaign: String(fd.get("campaign_id")), p_numbers: nums, p_coupon: String(fd.get("coupon") ?? "").trim() || null, p_minutes: auto ? 30 : 360,
  });
  if (error) volta(error.message);
  const orderId: string = data.order_id;
  if (data.total_cents <= 0) { await supabase.rpc("cancel_order", { p_order: orderId }); volta("Pedidos de valor zero ainda não são suportados."); }
  if (manual) redirect(`/conta/pedido/${orderId}`); // a página do pedido mostra a chave PIX, o QR Code e o valor exato
  try {
    // 2) cobrança PIX no provedor, com chave de idempotência = id do pedido (sem cobrança duplicada)
    const pix = await criarPix({ orderId, valorCentavos: data.total_cents, descricao: `RifaJá: ${(nums as number[]).length} número(s)`, email: user.email!, expiraEm: new Date(data.reserved_until) });
    const { error: e2 } = await adminClient().from("payments").insert({
      order_id: orderId, provider: "mercadopago", provider_payment_id: pix.id, amount_cents: data.total_cents,
      qr_code: pix.qr, qr_code_base64: pix.qr64, ticket_url: pix.ticket, expires_at: data.reserved_until,
    });
    if (e2) throw e2;
  } catch {
    await supabase.rpc("cancel_order", { p_order: orderId });
    volta("Não foi possível iniciar o pagamento. Seus números foram liberados. Tente de novo.");
  }
  redirect(`/conta/pedido/${orderId}`);
}

const MOTIVOS: Record<string, string> = {
  not_found: "Cupom não encontrado.", expired: "Cupom expirado.", not_started: "Esse cupom ainda não começou.",
  min_order: "A compra está abaixo do valor mínimo desse cupom.", limit_reached: "Cupom esgotado.",
  user_limit: "Você já usou esse cupom.", not_eligible: "Esse cupom vale só para novos clientes ou primeira compra.", login_required: "Entre na sua conta para usar cupom.",
};
// Só mostra o desconto na tela. O valor final é sempre recalculado e cobrado pelo servidor na hora da reserva.
export async function conferirCupom(code: string, subtotalCents: number): Promise<{ ok: true; desconto: number } | { ok: false; msg: string }> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { ok: false, msg: MOTIVOS.login_required };
  const { data, error } = await supabase.rpc("validate_coupon", { p_code: String(code ?? "").slice(0, 40), p_total_cents: Math.max(0, Math.floor(Number(subtotalCents) || 0)) });
  if (error || !data?.valid) return { ok: false, msg: MOTIVOS[data?.reason as string] ?? "Cupom inválido." };
  return { ok: true, desconto: Number(data.discount_cents) };
}
