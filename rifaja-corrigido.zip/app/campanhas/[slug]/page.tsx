import { notFound } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import { brl } from "../../../lib/periodo";
import NumberPicker from "../../../components/NumberPicker";
import { pagamentoConfigurado } from "../../../lib/payments/config";
export const dynamic = "force-dynamic";
const dt = (v: string | null) => (v ? new Date(v).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" }) : "a definir");
const ROT: Record<string, string> = { ativa: "Ativa", agendada: "Em breve", encerrada: "Encerrada", rascunho: "Rascunho (só a equipe vê)", pendente_revisao: "Em revisão (só a equipe vê)", pausada: "Pausada", cancelada: "Cancelada" };

export default async function Campanha({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ erro?: string }> }) {
  const { slug } = await params;
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: c } = await supabase.from("campaigns").select("*").eq("slug", slug).maybeSingle();
  if (!c) notFound();
  const [{ data: imgs }, { data: tomados }, { data: { user } }] = await Promise.all([
    supabase.from("campaign_images").select("id,url,alt").eq("campaign_id", c.id).order("position"),
    supabase.rpc("taken_numbers", { p_campaign: c.id }),
    supabase.auth.getUser(),
  ]);
  const taken: Record<number, string> = {};
  (tomados ?? []).forEach((t: { number: number; status: string }) => { taken[t.number] = t.status; });
  const pixManual = !!(await supabase.rpc("pix_manual_ativo")).data;
  const temTabela = !!c.total_numbers && c.price_cents != null;
  const aberta = temTabela && c.status === "ativa" && c.legal_validated;
  const motivo = !c.legal_validated ? "a validação jurídica ainda não foi marcada." : c.status !== "ativa" ? `a rifa está com status “${ROT[c.status] ?? c.status}”.` : "";
  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <div className="relative overflow-hidden rounded-3xl bg-[#0A1B4D] text-white shadow-lg">
        {c.cover_url /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={c.cover_url} alt={c.name} className="h-56 w-full object-cover opacity-70 sm:h-72" />
          : <div className="h-40 bg-gradient-to-br from-[#13286B] to-[#1E5BFF]" />}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#0A1B4D] to-transparent p-5 pt-16">
          <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-bold backdrop-blur">{ROT[c.status] ?? c.status}</span>
          <h1 className="mt-2 text-3xl font-extrabold leading-tight sm:text-4xl">{c.name}</h1>
          {c.prize && <p className="mt-1 text-lg text-white/85">{c.prize}</p>}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[["Valor por número", c.price_cents != null ? brl(c.price_cents) : "—"], ["Números", c.total_numbers ?? "—"], ["Início", dt(c.starts_at)], ["Encerramento", dt(c.ends_at)]].map(([t, v]) => (
          <div key={String(t)} className="rounded-2xl border bg-white p-3 text-center shadow-sm"><div className="text-xs text-slate-500">{t}</div><div className="text-lg font-extrabold">{v}</div></div>))}
      </div>

      {c.description && <p className="mt-5 whitespace-pre-line text-slate-700">{c.description}</p>}
      {sp.erro && <p role="alert" className="mt-5 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      {temTabela
        ? <NumberPicker campaignId={c.id} slug={c.slug} total={c.total_numbers} priceCents={c.price_cents} limit={c.participation_limit} taken={taken} logged={!!user} pagamentoAtivo={pagamentoConfigurado() || pixManual} modo={pagamentoConfigurado() ? "auto" : "manual"} aberta={aberta} motivo={motivo} />
        : <p className="mt-8 rounded-xl bg-amber-100 p-4 text-sm text-amber-900">Defina a quantidade de números e o valor por número para a tabela aparecer.</p>}

      {!!imgs?.length && <div className="mt-8 grid grid-cols-2 gap-3">{imgs.map((i: any) => /* eslint-disable-next-line @next/next/no-img-element */ <img key={i.id} src={i.url} alt={i.alt ?? c.name} className="rounded-2xl" />)}</div>}
      {c.rules && <section className="mt-8 rounded-2xl border bg-white p-5"><h2 className="text-xl font-bold">Regulamento</h2><p className="mt-2 whitespace-pre-line text-slate-700">{c.rules}</p></section>}
      {c.organizer_info && <p className="mt-4 text-sm text-slate-600"><b>Responsável:</b> {c.organizer_info}</p>}
    </main>
  );
}
