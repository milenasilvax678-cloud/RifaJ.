import { redirect } from "next/navigation";
import { createClient } from "../../lib/supabase/server";
import SubmitButton from "../../components/SubmitButton";
import { entrar } from "./actions";
export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false, follow: false } };

export default async function AcessoRestrito({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("is_owner")).data) redirect("/");
  return (
    <main className="grid min-h-[70vh] place-items-center bg-[#050B24] px-4 py-10 text-white">
      <form action={entrar} className="grid w-full max-w-sm gap-4 rounded-3xl border border-[#7F8FFF44] bg-[#0F1A55]/70 p-6 shadow-2xl">
        <div className="text-center"><div className="text-4xl">🔒</div><h1 className="mt-2 text-2xl font-extrabold">Área restrita</h1>
          <p className="mt-1 text-sm text-[#9FB0E8]">Digite a chave de acesso do painel.</p></div>
        {sp.erro && <p role="alert" className="rounded-xl bg-red-500/15 p-3 text-sm text-red-300">{sp.erro}</p>}
        <input name="chave" type="password" required autoComplete="off" autoFocus placeholder="Chave de acesso" aria-label="Chave de acesso"
          className="rounded-xl border border-[#7F8FFF55] bg-[#0B1440] p-3 text-white placeholder:text-[#7F8FCB]" />
        <SubmitButton carregando="Verificando…">Entrar no painel</SubmitButton>
        <p className="text-center text-xs text-[#9FB0E8]">Depois de 5 erros, o acesso fica bloqueado por 15 minutos.</p>
      </form>
    </main>
  );
}
