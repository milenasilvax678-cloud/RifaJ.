"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../lib/supabase/server";
const volta = (ok: boolean, m: string): never => redirect(`/conta?${ok ? "ok" : "erro"}=${encodeURIComponent(m)}`);

export async function salvarPerfil(fd: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const nome = String(fd.get("full_name") ?? "").trim(), tel = String(fd.get("phone") ?? "").replace(/[^\d+]/g, "");
  if (nome.length < 3 || tel.length < 10) volta(false, "Informe nome completo e telefone com DDD.");
  const { error } = await supabase.from("profiles").update({ full_name: nome, phone: tel }).eq("id", user!.id);
  revalidatePath("/conta");
  volta(!error, error ? error.message : "Dados salvos.");
}
export async function usarCodigo(fd: FormData) {
  const supabase = await createClient();
  const { data } = await supabase.rpc("use_referral_code", { p_code: String(fd.get("code") ?? "") });
  volta(!!data, data ? "Indicação registrada." : "Código inválido, ou você já informou uma indicação.");
}
