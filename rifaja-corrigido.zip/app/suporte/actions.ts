"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../lib/supabase/server";

export async function abrirChamado(fd: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  // A função do banco valida tudo e grava o chamado e a primeira mensagem juntos.
  const { data, error } = await supabase.rpc("open_ticket", {
    p_subject: String(fd.get("subject") ?? ""), p_category: String(fd.get("category") ?? "outro"), p_body: String(fd.get("body") ?? ""),
  });
  if (error) redirect(`/suporte/novo?erro=${encodeURIComponent(error.message)}`);
  revalidatePath("/suporte");
  redirect(`/suporte/${data}?ok=${encodeURIComponent("Chamado aberto. A equipe vai responder aqui.")}`);
}

export async function responderChamado(fd: FormData) {
  const id = String(fd.get("id"));
  const body = String(fd.get("body") ?? "").trim();
  if (!body) redirect(`/suporte/${id}?erro=${encodeURIComponent("Escreva sua mensagem.")}`);
  const supabase = await createClient();
  const { error } = await supabase.from("ticket_messages").insert({ ticket_id: id, body });
  revalidatePath(`/suporte/${id}`);
  redirect(`/suporte/${id}?${error ? "erro" : "ok"}=${encodeURIComponent(error ? error.message : "Mensagem enviada.")}`);
}
