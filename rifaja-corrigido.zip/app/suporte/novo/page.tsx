import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import { CATEGORIAS } from "../../../lib/suporte";
import SubmitButton from "../../../components/SubmitButton";
import { abrirChamado } from "../actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default async function Novo({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  return (
    <main className="mx-auto max-w-xl px-4 py-10">
      <Link href="/suporte" className="text-sm font-bold text-[#1E5BFF]">← Central de suporte</Link>
      <h1 className="mt-2 text-3xl font-extrabold">Abrir chamado</h1>
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      <form action={abrirChamado} className="mt-6 grid gap-3 rounded-2xl border bg-white p-4 shadow-sm">
        <label className="grid gap-1 text-sm font-bold">Assunto<input name="subject" required minLength={3} maxLength={120} placeholder="Resumo do problema" className={inp + " font-normal"} /></label>
        <label className="grid gap-1 text-sm font-bold">Categoria
          <select name="category" defaultValue="outro" className={inp + " font-normal"}>{Object.entries(CATEGORIAS).map(([v, t]) => <option key={v} value={v}>{t}</option>)}</select></label>
        <label className="grid gap-1 text-sm font-bold">Descreva o problema<textarea name="body" required minLength={10} maxLength={4000} rows={6} placeholder="Conte o que aconteceu, com o máximo de detalhes." className={inp + " font-normal"} /></label>
        <SubmitButton carregando="Enviando chamado…">Enviar chamado</SubmitButton>
      </form>
    </main>
  );
}
