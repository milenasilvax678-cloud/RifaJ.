import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import AdminNav from "../nav";
import SocialIcon, { NOME_REDE } from "../../../components/SocialIcon";
import SubmitButton from "../../../components/SubmitButton";
import { salvarRedes, salvarPix } from "./actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default async function Config({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "settings.manage" })).data) redirect("/admin");
  const { data: pix } = await supabase.from("payment_settings").select("pix_key,pix_name,pix_city").eq("id", 1).maybeSingle();
  const { data } = await supabase.from("social_links").select("*").order("position");
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Configurações</h1>
      <h2 className="mt-4 text-xl font-bold">Recebimento por PIX</h2>
      <p className="text-sm text-slate-600">Chave que os clientes usam para pagar quando não há provedor automático. Só você vê e edita. Dica: prefira uma chave aleatória; se usar CPF, ele aparece para quem for comprar.</p>
      <form action={salvarPix} className="mt-3 grid gap-3 rounded-2xl border bg-white p-4">
        <input name="pix_key" required defaultValue={pix?.pix_key ?? ""} placeholder="Chave PIX" className={inp} />
        <input name="pix_name" maxLength={25} defaultValue={pix?.pix_name ?? ""} placeholder="Nome do recebedor (até 25 letras)" className={inp} />
        <input name="pix_city" maxLength={15} defaultValue={pix?.pix_city ?? ""} placeholder="Cidade (até 15 letras)" className={inp} />
        <SubmitButton carregando="Salvando…">Salvar chave PIX</SubmitButton>
      </form>
      <h2 className="mt-10 text-xl font-bold">Redes sociais</h2>
      <p className="text-sm text-slate-600">Ative só as redes que existem de verdade e cole o link do perfil. Rede sem link não aparece no site.</p>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      <form action={salvarRedes} className="mt-5 grid gap-4">
        {data?.map((r: any) => (
          <fieldset key={r.network} className="grid gap-2 rounded-2xl border bg-white p-4">
            <legend className="flex items-center gap-2 px-1 text-lg font-bold"><SocialIcon network={r.network} size={22} /> {NOME_REDE[r.network]}</legend>
            <label className="flex items-center gap-2 text-sm font-bold"><input type="checkbox" name={`${r.network}__enabled`} defaultChecked={r.enabled} /> Exibir no site</label>
            <input name={`${r.network}__url`} defaultValue={r.url ?? ""} placeholder="Link do perfil (https://...)" inputMode="url" className={inp} />
            <input name={`${r.network}__title`} defaultValue={r.title ?? ""} maxLength={60} placeholder="Título do card" className={inp} />
            <input name={`${r.network}__description`} defaultValue={r.description ?? ""} maxLength={160} placeholder="Descrição curta" className={inp} />
            <label className="grid gap-1 text-sm">Ordem (menor aparece primeiro)<input name={`${r.network}__position`} type="number" defaultValue={r.position} className={inp} /></label>
            <div className="flex flex-wrap gap-4 text-sm">
              <label className="flex gap-2"><input type="checkbox" name={`${r.network}__footer`} defaultChecked={r.show_footer} /> Rodapé</label>
              <label className="flex gap-2"><input type="checkbox" name={`${r.network}__home`} defaultChecked={r.show_home} /> Página inicial</label>
              <label className="flex gap-2"><input type="checkbox" name={`${r.network}__contact`} defaultChecked={r.show_contact} /> Página de contato</label>
            </div>
          </fieldset>))}
        <SubmitButton carregando="Salvando…">Salvar redes sociais</SubmitButton>
      </form>
    </main>
  );
}
