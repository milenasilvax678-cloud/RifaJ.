import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import { brl } from "../../../lib/periodo";
import AdminNav from "../nav";
import AutoRefresh from "../../../components/AutoRefresh";
import { confirmarManual } from "./actions";
export const dynamic = "force-dynamic";
const ROT: Record<string, string> = { pendente: "Pendente", aprovado: "Confirmado", recusado: "Recusado", expirado: "Expirado", reembolsado: "Reembolsado" };

export default async function Pagamentos({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string; s?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "orders.read" })).data) redirect("/admin");
  const manual = !!(await supabase.rpc("has_permission", { perm: "payments.manual_confirm" })).data;
  const [{ data }, { data: cont }] = await Promise.all([supabase.rpc("admin_payments"), supabase.rpc("campaign_counts")]);
  const todos = (data ?? []) as any[];
  const lista = todos.filter((p) => !sp.s || p.pay_status === sp.s);
  const n = (s: string) => todos.filter((p) => p.pay_status === s).length;
  const reservados = (cont ?? []).reduce((a: number, c: any) => a + c.reserved, 0), pagos = (cont ?? []).reduce((a: number, c: any) => a + c.sold, 0);
  const pendentes = todos.filter((p) => p.pay_status === "pendente");
  const { data: ordsP } = await supabase.rpc("admin_orders");
  const ordsPend = ((ordsP ?? []) as any[]).filter((o) => o.order_status === "pendente");
  const cards: [string, number][] = [["Pendentes", n("pendente")], ["Confirmados", n("aprovado")], ["Recusados", n("recusado")], ["Expirados", n("expirado")], ["Para conferir", todos.filter((p) => p.needs_review).length], ["Números reservados", reservados], ["Números pagos", pagos]];
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <AutoRefresh />
      <h1 className="text-3xl font-extrabold">Pagamentos e participações</h1>
      <p className="text-slate-600">Somente consulta. A confirmação vem do provedor de pagamento, por webhook validado no servidor.</p>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">{cards.map(([t, v]) => <div key={t} className="rounded-2xl border bg-white p-3"><div className="text-xs text-slate-500">{t}</div><div className="text-2xl font-extrabold">{v}</div></div>)}</div>
      <div className="mt-5 flex flex-wrap gap-2">
        {[["", "Todos"], ["pendente", "Pendentes"], ["aprovado", "Confirmados"], ["recusado", "Recusados"], ["expirado", "Expirados"]].map(([v, t]) => (
          <a key={t} href={`/admin/pagamentos${v ? `?s=${v}` : ""}`} className={`rounded-lg border px-3 py-1 text-sm font-bold ${(sp.s ?? "") === v ? "bg-[#1E5BFF] text-white" : "bg-white"}`}>{t}</a>))}
      </div>
      <ul className="mt-5 grid gap-3">
        {lista.map((p) => (
          <li key={p.payment_id} className="rounded-2xl border bg-white p-4 text-sm">
            <div className="flex flex-wrap justify-between gap-2"><b>{p.campaign_name}</b><span className="font-bold">{ROT[p.pay_status] ?? p.pay_status}</span></div>
            <p>{brl(p.amount_cents)} · números: <b>{(p.picked ?? []).join(", ") || "—"}</b></p>
            <p className="text-slate-500">Criado {new Date(p.created_at).toLocaleString("pt-BR")} · atualizado {new Date(p.updated_at).toLocaleString("pt-BR")}{p.expires_at ? ` · expira ${new Date(p.expires_at).toLocaleString("pt-BR")}` : ""}</p>
            {p.needs_review && <p className="mt-2 rounded-lg bg-amber-100 p-2 text-amber-900">Conferir: {p.review_note}</p>}
            <details className="mt-2"><summary className="cursor-pointer font-bold text-[#1E5BFF]">Histórico de atualizações</summary>
              <ul className="mt-1 grid gap-1 text-xs">{(p.events ?? []).map((e: any, i: number) => <li key={i}>{new Date(e.at).toLocaleString("pt-BR")} · {e.result} · {e.event}</li>)}
                {!(p.events ?? []).length && <li>Nenhum evento recebido ainda.</li>}</ul></details>
          </li>))}
        {!lista.length && <li className="rounded-xl border-2 border-dashed p-5 text-slate-600">Nenhum pagamento neste filtro.</li>}
      </ul>
      <section className="mt-10 rounded-2xl border border-amber-300 bg-white p-4">
        <h2 className="text-lg font-bold">Confirmação manual (exceção)</h2>
        {manual ? (
          <form action={confirmarManual} className="mt-2 grid gap-2">
            <p className="text-sm text-slate-600">Use só quando o pagamento foi comprovado fora do fluxo automático. Fica registrado com seu usuário e a justificativa.</p>
            <select name="order_id" required className="rounded-xl border p-3">{ordsPend.map((o) => <option key={o.order_id} value={o.order_id}>{o.campaign_name} · {o.buyer_name ?? o.buyer_email} · {o.buyer_phone ?? ""} · {brl(o.total_cents)} · números {(o.picked ?? []).join(", ")}</option>)}</select>
            <textarea name="reason" required minLength={15} rows={3} placeholder="Justificativa (mínimo 15 caracteres)" className="rounded-xl border p-3" />
            <button disabled={!ordsPend.length} className="w-fit rounded-xl bg-[#0A1B4D] px-4 py-2 font-bold text-white disabled:opacity-40">Confirmar manualmente</button>
          </form>
        ) : <p className="mt-2 text-sm text-slate-600">Seu cargo só consulta. A confirmação manual exige a permissão <b>payments.manual_confirm</b>, uma justificativa e fica na auditoria.</p>}
      </section>
    </main>
  );
}
