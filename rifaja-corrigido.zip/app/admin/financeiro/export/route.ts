import { NextResponse } from "next/server";
import { createClient } from "../../../../lib/supabase/server";
import { periodo } from "../../../../lib/periodo";

// Evita que o Excel execute fórmulas em campos de texto
const cel = (v: unknown) => {
  let s = String(v ?? "");
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
};

export async function GET(req: Request) {
  const supabase = await createClient();
  const ok = (await supabase.rpc("has_permission", { perm: "finance.export" })).data;
  if (!ok) return new NextResponse("Sem permissão", { status: 403 });

  const sp = Object.fromEntries(new URL(req.url).searchParams);
  const { ini, fim, iniDia, fimDia } = periodo(sp);
  const [tx, ex, aj] = await Promise.all([
    supabase.from("transactions").select("type,amount_cents,status,occurred_at,note").gte("occurred_at", ini).lte("occurred_at", fim),
    supabase.from("expenses").select("description,amount_cents,incurred_on,category").gte("incurred_on", iniDia).lte("incurred_on", fimDia),
    supabase.from("financial_adjustments").select("description,amount_cents,created_at,justification").gte("created_at", ini).lte("created_at", fim),
  ]);
  const v = (c: number) => (c / 100).toFixed(2).replace(".", ",");
  const linhas = [
    ["registro", "data", "descricao", "valor_reais", "status"],
    ...(tx.data ?? []).map((x) => ["transacao:" + x.type, x.occurred_at, x.note, v(x.amount_cents), x.status]),
    ...(ex.data ?? []).map((x) => ["despesa", x.incurred_on, x.description, v(-x.amount_cents), x.category]),
    ...(aj.data ?? []).map((x) => ["ajuste", x.created_at, `${x.description} (${x.justification})`, v(x.amount_cents), ""]),
  ];
  const csv = "\uFEFF" + linhas.map((l) => l.map(cel).join(";")).join("\r\n");
  return new NextResponse(csv, {
    headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="rifaja-financeiro-${iniDia}_${fimDia}.csv"` },
  });
}
