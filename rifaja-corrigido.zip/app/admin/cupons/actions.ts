"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const txt = (fd: FormData, k: string) => (String(fd.get(k) ?? "").trim() || null);
const num = (fd: FormData, k: string) => { const v = txt(fd, k); return v ? Number(v.replace(",", ".")) : null; };
const done = (ok: boolean, msg: string): never => redirect(`/admin/cupons?${ok ? "ok" : "erro"}=${encodeURIComponent(msg)}`);

const H = 3600e3;
const DURACAO: Record<string, number> = { "1h": H, "6h": 6 * H, "24h": 24 * H, "7d": 168 * H, "30d": 720 * H };
// datetime-local vem sem fuso: tratamos como horário de Brasília (UTC-3).
const brasilia = (v: string) => new Date(`${v}:00-03:00`);

export async function criarCupom(fd: FormData) {
  const supabase = await createClient();
  const code = txt(fd, "code")?.toUpperCase().replace(/\s+/g, "");
  if (!code || !/^[A-Z0-9_-]{3,30}$/.test(code)) done(false, "Nome do cupom: de 3 a 30 letras ou números, sem espaços.");
  const valor = num(fd, "discount_value");
  if (!valor || valor <= 0) done(false, "Informe um desconto maior que zero.");
  const percentual = fd.get("discount_type") === "percentual";
  if (percentual && valor! > 100) done(false, "Percentual não pode passar de 100.");

  const dur = txt(fd, "duration") ?? "24h";
  let expira: string | null = null;
  if (dur === "custom") {
    const e = txt(fd, "expires_at");
    if (!e) done(false, "Escolha a data e hora do fim do cupom.");
    expira = brasilia(e!).toISOString();
    if (new Date(expira).getTime() <= Date.now()) done(false, "O fim do cupom precisa estar no futuro.");
  } else if (DURACAO[dur]) expira = new Date(Date.now() + DURACAO[dur]).toISOString();

  const min = num(fd, "min_order");
  const { error } = await supabase.from("coupons").insert({
    code, discount_type: percentual ? "percentual" : "valor_fixo",
    discount_value: percentual ? valor : Math.round(valor! * 100), // valor fixo em centavos
    min_order_cents: min ? Math.round(min * 100) : 0,
    starts_at: new Date().toISOString(), expires_at: expira, active: true,
    max_uses: num(fd, "max_uses"), max_uses_per_user: num(fd, "max_uses_per_user") ?? 1,
    new_customers_only: fd.get("new_customers_only") === "on",
    first_purchase_only: fd.get("first_purchase_only") === "on",
  });
  revalidatePath("/admin/cupons");
  done(!error, error ? (error.code === "23505" ? "Esse nome de cupom já existe." : error.message) : `Cupom ${code} ativado${expira ? ` até ${new Date(expira).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}` : " sem prazo para acabar"}.`);
}

export async function alternarCupom(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.from("coupons").update({ active: fd.get("ativar") === "1" }).eq("id", txt(fd, "id"));
  revalidatePath("/admin/cupons");
  done(!error, error ? error.message : fd.get("ativar") === "1" ? "Cupom ativado." : "Cupom desativado.");
}

// Prorroga o tempo: soma a duração ao que resta (ou a partir de agora, se já expirou) e reativa.
export async function prorrogarCupom(fd: FormData) {
  const supabase = await createClient();
  const id = txt(fd, "id");
  const add = DURACAO[txt(fd, "duration") ?? ""];
  if (!add) done(false, "Escolha quanto tempo somar.");
  const { data: c } = await supabase.from("coupons").select("expires_at").eq("id", id).maybeSingle();
  const base = Math.max(Date.now(), c?.expires_at ? new Date(c.expires_at).getTime() : 0);
  const { error } = await supabase.from("coupons").update({ expires_at: new Date(base + add).toISOString(), active: true }).eq("id", id);
  revalidatePath("/admin/cupons");
  done(!error, error ? error.message : "Tempo do cupom prorrogado.");
}
