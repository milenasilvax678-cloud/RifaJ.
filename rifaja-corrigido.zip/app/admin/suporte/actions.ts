"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";
const volta = (id: string, ok: boolean, m: string): never => redirect(`/admin/suporte/${id}?${ok ? "ok" : "erro"}=${encodeURIComponent(m)}`);

export async function responderStaff(fd: FormData) {
  const id = String(fd.get("id")), body = String(fd.get("body") ?? "").trim();
  if (!body) volta(id, false, "Escreva a mensagem.");
  const supabase = await createClient();
  const interna = fd.get("internal") === "on";
  // O banco só aceita is_staff para quem tem a permissão support.write.
  const { error } = await supabase.from("ticket_messages").insert({ ticket_id: id, body, is_staff: true, is_internal: interna });
  revalidatePath(`/admin/suporte/${id}`);
  volta(id, !error, error ? error.message : interna ? "Nota interna salva (o usuário não vê)." : "Resposta enviada ao usuário.");
}

export async function alterarStatusChamado(fd: FormData) {
  const id = String(fd.get("id"));
  const supabase = await createClient();
  const { error, count } = await supabase.from("support_tickets").update({ status: String(fd.get("status")) }, { count: "exact" }).eq("id", id);
  revalidatePath(`/admin/suporte/${id}`); revalidatePath("/admin/suporte");
  volta(id, !error && !!count, error ? error.message : count ? "Status atualizado." : "Sem permissão para alterar o status.");
}
