import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import { brl } from "../../../lib/periodo";
import AdminNav from "../nav";
import AutoRefresh from "../../../components/AutoRefresh";
import { cancelarOuReembolsar } from "./actions";
export const dynamic = "force-dynamic";

export default async function Compras({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string; s?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "buyers.read" })).data) redirect("/admin");
  const gestor = !!(await supabase.rpc("has_permission", { perm: "orders.manage" })).data;
  const { data } = await supabase.rpc("admin_orders");
  const lista = (data ?? []).filter((o: any) => !sp.s || o.order_status === sp.s);
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <AutoRefresh />
      <h1 className="text-3xl font-extrabold">Compras e compradores</h1>
      <p className="text-slate-600">Dados pessoais protegidos pela LGPD: só quem tem a permissão <b>buyers.read</b> vê esta página.</p>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      <div className="mt-4 flex flex-wrap gap-2">
        {[["", "Todos"], ["pendente", "Pendentes"], ["confirmado", "Confirmados"], ["cancelado", "Cancelados"], ["reembolsado", "Reembolsados"]].map(([v, t]) => (
          <a key={t} href={`/admin/compras${v ? `?s=${v}` : ""}`} className={`rounded-lg border px-3 py-1 text-sm font-bold ${(sp.s ?? "") === v ? "bg-[#1E5BFF] text-white" : "bg-white"}`}>{t}</a>))}
      </div>
      <ul className="mt-6 grid gap-3">
        {lista.map((o: any) => (
          <li key={o.order_id} className="rounded-2xl border bg-white p-4 text-sm">
            <div className="flex flex-wrap justify-between gap-2">
              <b>{o.campaign_name}</b><span className="font-bold">{o.order_status}</span>
            </div>
            <p className="mt-1">{o.buyer_name ?? "Sem nome"} · {o.buyer_email} · {o.buyer_phone ?? "sem telefone"}</p>
            <p>{o.qty} número(s): <b>{(o.picked ?? []).join(", ") || "—"}</b> · {brl(o.total_cents)} · {new Date(o.ordered_at).toLocaleString("pt-BR")}</p>
            {gestor && (o.order_status === "pendente" || o.order_status === "confirmado") && (
              <div className="mt-3 flex gap-2">
                
                <form action={cancelarOuReembolsar}><input type="hidden" name="id" value={o.order_id} />
                  <button className="rounded-lg border px-3 py-2 font-bold text-red-700">{o.order_status === "pendente" ? "Cancelar" : "Reembolsar"}</button></form>
              </div>)}
          </li>))}
        {!lista.length && <li className="rounded-xl border-2 border-dashed p-5 text-slate-600">Nenhuma compra registrada.</li>}
      </ul>
    </main>
  );
}
