"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";
const volta = (ok: boolean, m: string): never => redirect(`/admin/compras?${ok ? "ok" : "erro"}=${encodeURIComponent(m)}`);

export async function cancelarOuReembolsar(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.rpc("cancel_order", { p_order: String(fd.get("id")) });
  revalidatePath("/admin/compras");
  volta(!error, error ? error.message : "Pedido cancelado e números liberados.");
}
