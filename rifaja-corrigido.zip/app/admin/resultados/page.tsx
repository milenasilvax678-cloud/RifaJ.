import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import AdminNav from "../nav";
import { anunciarGanhador, alterarPublicacao } from "./actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default async function Resultados({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "results.write" })).data) redirect("/admin");
  const [{ data: camps }, { data: res }] = await Promise.all([
    supabase.from("campaigns").select("id,name").in("status", ["ativa", "encerrada"]).eq("legal_validated", true).order("name"),
    supabase.from("campaign_results").select("id,winner_name,announcement,proof_url,drawn_at,published,campaigns(name)").order("created_at", { ascending: false }),
  ]);
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Anunciar ganhador</h1>
      <p className="text-slate-600">O resultado aparece na página inicial. Use apenas resultados reais e, de preferência, só o primeiro nome e a inicial do sobrenome (LGPD).</p>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}
      {camps?.length ? (
        <form action={anunciarGanhador} className="mt-6 grid gap-3 rounded-2xl border bg-white p-4">
          <select name="campaign_id" className={inp}>{camps.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
          <input name="winner_name" required placeholder="Ganhador (ex.: Maria S.)" className={inp} />
          <input type="date" name="drawn_at" className={inp} aria-label="Data do resultado" />
          <input name="proof_url" placeholder="Link do comprovante (https://...)" className={inp} />
          <textarea name="announcement" rows={3} placeholder="Mensagem do anúncio" className={inp} />
          <button className="rounded-xl bg-[#1E5BFF] p-3 font-bold text-white">Publicar resultado</button>
        </form>
      ) : <p className="mt-6 rounded-xl border-2 border-dashed p-4 text-slate-600">Nenhuma campanha ativa ou encerrada com validação jurídica. Só essas podem receber resultado.</p>}
      <h2 className="mt-8 text-xl font-bold">Resultados publicados</h2>
      <ul className="mt-3 grid gap-2">
        {res?.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-white p-3 text-sm">
            <span><b>{(r.campaigns as any)?.name}</b> · {r.winner_name} {r.published ? "" : "(oculto)"}</span>
            <form action={alterarPublicacao}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="publicar" value={r.published ? "0" : "1"} />
              <button className="rounded-lg border px-3 py-1 font-bold">{r.published ? "Ocultar" : "Mostrar"}</button></form>
          </li>
        ))}
        {!res?.length && <li className="text-slate-600">Nenhum resultado ainda.</li>}
      </ul>
    </main>
  );
}
