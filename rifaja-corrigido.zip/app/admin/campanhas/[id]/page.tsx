import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../../lib/supabase/server";
import AdminNav from "../../nav";
import { editarCampanha, enviarFotos, removerFoto, excluirCampanha } from "./actions";
import ProductEditor from "../../../../components/ProductEditor";
import ImagePicker from "../../../../components/ImagePicker";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";
const loc = (v: string | null) => (v ? new Date(new Date(v).getTime() - 3 * 3600e3).toISOString().slice(0, 16) : ""); // horário de Brasília

export default async function EditarCampanha({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "campaigns.write" })).data) redirect("/admin");
  const { data: c } = await supabase.from("campaigns").select("*").eq("id", id).maybeSingle();
  if (!c) notFound();
  const { data: fotos } = await supabase.from("campaign_images").select("id,url").eq("campaign_id", id).order("position");
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <AdminNav />
      <Link href="/admin/campanhas" className="text-sm font-bold text-[#1E5BFF]">← Campanhas</Link>
      <h1 className="mt-2 text-3xl font-extrabold">Editar: {c.name}</h1>
      <div className="flex flex-wrap gap-4"><Link href={`/admin/campanhas/${id}/numeros`} className="text-sm font-bold text-[#1E5BFF]">Ver tabela de números →</Link><Link href={`/campanhas/${c.slug}`} className="text-sm font-bold text-[#1E5BFF]">Pré-visualizar a página →</Link></div>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      <ProductEditor action={editarCampanha} c={{
        id: c.id, name: c.name, prize: c.prize ?? "", category: c.category ?? "", description: c.description ?? "", rules: c.rules ?? "", organizer_info: c.organizer_info ?? "",
        starts_at: loc(c.starts_at), ends_at: loc(c.ends_at), price: c.price_cents != null ? (c.price_cents / 100).toFixed(2) : "",
        participation_limit: c.participation_limit != null ? String(c.participation_limit) : "", total_numbers: c.total_numbers != null ? String(c.total_numbers) : "", cover_url: c.cover_url ?? null }} />

      <h2 className="mt-10 text-2xl font-bold">Galeria de fotos</h2>
      <form action={enviarFotos} className="mt-3 grid gap-3 rounded-2xl border bg-white p-4">
        <input type="hidden" name="id" value={c.id} />
        <ImagePicker name="fotos" multiple label="Adicionar fotos (até 5 MB cada)" />
        <button className="rounded-xl bg-[#0A1B4D] p-3 font-bold text-white">Enviar fotos</button>
      </form>
      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {fotos?.map((f) => (
          <div key={f.id} className="rounded-xl border bg-white p-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={f.url} alt="" className="h-32 w-full rounded-lg object-cover" />
            <form action={removerFoto} className="mt-2"><input type="hidden" name="id" value={c.id} /><input type="hidden" name="foto_id" value={f.id} />
              <button className="w-full rounded-lg border py-1 text-sm font-bold text-red-700">Remover</button></form>
          </div>
        ))}
        {!fotos?.length && <p className="col-span-full rounded-xl border-2 border-dashed p-4 text-slate-600">Nenhuma foto na galeria.</p>}
      </div>
      <form action={excluirCampanha} className="mt-10 grid gap-2 rounded-2xl border border-red-200 bg-white p-4">
        <input type="hidden" name="id" value={c.id} />
        <h2 className="text-lg font-bold text-red-700">Excluir rifa</h2>
        <p className="text-sm text-slate-600">Só o dono pode excluir. Não é possível excluir se já houver pedidos.</p>
        <label className="flex gap-2 text-sm"><input type="checkbox" required /> Entendo que isso não pode ser desfeito</label>
        <button className="w-fit rounded-xl border border-red-300 px-4 py-2 font-bold text-red-700">Excluir definitivamente</button>
      </form>
    </main>
  );
}
