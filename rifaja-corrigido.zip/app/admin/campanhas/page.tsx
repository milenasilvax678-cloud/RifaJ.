import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import { brl } from "../../../lib/periodo";
import ImagePicker from "../../../components/ImagePicker";
import { criarCampanha, mudarStatus, validarJuridico } from "./actions";
import { excluirCampanha } from "./[id]/actions";
export const dynamic = "force-dynamic";

const STATUS = ["rascunho", "pendente_revisao", "agendada", "ativa", "pausada", "encerrada", "cancelada"];
const COR: Record<string, string> = { ativa: "bg-green-400/20 text-green-300", pausada: "bg-amber-400/20 text-amber-300", rascunho: "bg-slate-400/20 text-slate-300", pendente_revisao: "bg-indigo-400/20 text-indigo-300", agendada: "bg-sky-400/20 text-sky-300", encerrada: "bg-slate-400/20 text-slate-300", cancelada: "bg-red-400/20 text-red-300" };
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";
const btn = "rounded-lg border px-3 py-2 text-center text-xs font-bold transition hover:brightness-125 sm:text-sm";

export default async function Rifas({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const perm = async (p: string) => !!(await supabase.rpc("has_permission", { perm: p })).data;
  if (!(await perm("campaigns.read"))) redirect("/admin");
  const [escreve, ehDono, orders] = await Promise.all([perm("campaigns.write"), supabase.rpc("is_owner").then((r) => !!r.data), perm("orders.read")]);
  const [{ data: lista }, { data: cont }] = await Promise.all([
    supabase.from("campaigns").select("id,slug,name,prize,status,legal_validated,total_numbers,price_cents,cover_url").order("created_at", { ascending: false }),
    supabase.rpc("campaign_counts"),
  ]);
  const k = (id: string) => (cont ?? []).find((x: any) => x.campaign_id === id) ?? { sold: 0, reserved: 0 };

  return (
    <main>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div><h2 className="text-2xl font-extrabold text-white">Gerenciar rifas</h2><p className="text-sm text-[#9FB0E8]">Visualize, edite e gerencie todas as suas rifas e campanhas.</p></div>
        {escreve && <a href="#nova" className="rounded-xl bg-gradient-to-r from-[#7C5CFF] to-[#4F46E5] px-5 py-3 font-bold text-white shadow-[0_0_18px_#4F46E577]">+ Nova rifa</a>}
      </div>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      {lista?.length ? (
        <div className="mt-5 overflow-x-auto rounded-3xl border border-[#7F8FFF33] bg-[#0F1A55]/60 backdrop-blur">
          <table className="w-full min-w-[960px] text-left text-sm">
            <thead className="text-xs text-[#9FB0E8]"><tr>{["Foto do prêmio", "Nome da rifa", "Prêmio", "Preço por número", "Total de números", "Vendidos", "Status", "Ações"].map((h) => <th key={h} className="p-4 font-semibold">{h}</th>)}</tr></thead>
            <tbody>
              {lista.map((r: any) => {
                const s = k(r.id), pct = r.total_numbers ? Math.round((s.sold / r.total_numbers) * 100) : 0;
                return (
                  <tr key={r.id} className="border-t border-[#7F8FFF22] align-top">
                    <td className="p-4">{r.cover_url /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={r.cover_url} alt={`Foto de ${r.name}`} className="h-20 w-20 rounded-xl object-cover" />
                      : <Link href={`/admin/campanhas/${r.id}#foto`} className="grid h-20 w-20 place-items-center rounded-xl border-2 border-dashed border-[#7F8FFF55] p-1 text-center text-xs text-[#9FB0E8]">Adicionar foto</Link>}</td>
                    <td className="p-4 font-bold text-white">{r.name}</td>
                    <td className="p-4 text-[#C3D1FF]">{r.prize ?? <span className="text-[#7F8FCB]">—</span>}</td>
                    <td className="p-4">{r.price_cents != null ? brl(r.price_cents) : "—"}</td>
                    <td className="p-4">{r.total_numbers ?? "—"}</td>
                    <td className="p-4">
                      <b className="text-white">{s.sold}</b>
                      <div className="mt-1 flex items-center gap-2"><div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-[#4F8BFF]" style={{ width: `${pct}%` }} /></div><span className="text-xs text-[#9FB0E8]">{pct}%</span></div>
                      {s.reserved > 0 && <div className="mt-1 text-xs text-amber-300">{s.reserved} reservados</div>}
                    </td>
                    <td className="p-4">
                      <span className={`rounded-full px-3 py-1 text-xs font-bold ${COR[r.status] ?? ""}`}>{r.status}</span>
                      {escreve && (
                        <form action={mudarStatus} className="mt-2 flex gap-1">
                          <input type="hidden" name="id" value={r.id} />
                          <select name="status" defaultValue={r.status} aria-label="Mudar status" className="w-28 rounded-lg border p-1 text-xs">{STATUS.map((x) => <option key={x}>{x}</option>)}</select>
                          <button className="rounded-lg bg-[#2D3FB0] px-2 text-xs font-bold text-white">OK</button>
                        </form>)}
                      <p className="mt-1 text-xs text-[#9FB0E8]">Jurídico: {r.legal_validated ? "validado" : "pendente"}</p>
                      {escreve && <form action={validarJuridico}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="valor" value={r.legal_validated ? "0" : "1"} /><button className="text-xs font-bold text-[#8FB0FF] underline">{r.legal_validated ? "Remover validação" : "Marcar validada"}</button></form>}
                    </td>
                    <td className="p-4">
                      <div className="grid w-64 grid-cols-2 gap-2">
                        {escreve && <Link href={`/admin/campanhas/${r.id}`} className={`${btn} border-[#6C7BFF] text-[#B7C3FF]`}>✎ Editar</Link>}
                        {orders && <Link href={`/admin/campanhas/${r.id}/numeros`} className={`${btn} border-[#38BDF8] text-[#7DD3FC]`}>▦ Editar números</Link>}
                        {escreve && <Link href={`/admin/campanhas/${r.id}#foto`} className={`${btn} border-[#A78BFA] bg-[#4F46E5]/30 text-[#DDD6FE]`}>▣ Trocar foto</Link>}
                        {escreve && <Link href={`/admin/campanhas/${r.id}#premio`} className={`${btn} border-[#2DD4BF] text-[#5EEAD4]`}>★ Editar prêmio</Link>}
                        <Link href={`/campanhas/${r.slug}`} className={`${btn} border-[#6C7BFF] text-[#B7C3FF]`}>ⓘ Ver detalhes</Link>
                        {ehDono && (
                          <details className="relative">
                            <summary className={`${btn} cursor-pointer list-none border-[#F87171] text-[#FCA5A5]`}>🗑 Excluir</summary>
                            <form action={excluirCampanha} className="absolute right-0 z-10 mt-1 grid w-60 gap-2 rounded-xl border border-red-400/40 bg-[#1A0F2E] p-3 shadow-xl">
                              <input type="hidden" name="id" value={r.id} />
                              <p className="text-xs text-[#FCA5A5]">Excluir “{r.name}” apaga a tabela, as fotos e os números. Não dá para desfazer. Se houver pedidos, o sistema não deixa excluir.</p>
                              <label className="flex gap-2 text-xs"><input type="checkbox" required /> Confirmo a exclusão</label>
                              <button className="rounded-lg bg-red-600 px-3 py-2 text-sm font-bold text-white">Excluir definitivamente</button>
                            </form>
                          </details>)}
                      </div>
                    </td>
                  </tr>);
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="mt-5 rounded-3xl border-2 border-dashed border-[#7F8FFF55] p-10 text-center">
          <p className="text-lg font-bold text-white">Você ainda não criou nenhuma rifa.</p>
          <p className="mt-1 text-[#9FB0E8]">Crie a primeira: a tabela de números e a página de pagamento são geradas automaticamente.</p>
          {escreve && <a href="#nova" className="mt-4 inline-block rounded-xl bg-gradient-to-r from-[#7C5CFF] to-[#4F46E5] px-6 py-3 font-bold text-white">+ Criar a primeira rifa</a>}
        </div>
      )}
      {!ehDono && lista?.length ? <p className="mt-2 text-xs text-[#9FB0E8]">Excluir rifas é permitido só ao dono.</p> : null}

      {escreve && (
        <form id="nova" action={criarCampanha} className="mt-8 grid scroll-mt-24 gap-3 rounded-3xl border border-[#7F8FFF33] bg-[#0F1A55]/60 p-5">
          <h2 className="text-xl font-bold text-white">Nova rifa (entra como rascunho)</h2>
          <input name="name" required placeholder="Nome da rifa" className={inp} />
          <input name="prize" maxLength={160} placeholder="Prêmio (ex.: PlayStation 5 Slim 1TB)" className={inp} />
          <input name="category" placeholder="Categoria (opcional)" className={inp} />
          <textarea name="description" placeholder="Descrição do prêmio" className={inp} />
          <textarea name="rules" placeholder="Regulamento" className={inp} />
          <input name="organizer_info" placeholder="Responsável pela rifa" className={inp} />
          <div className="grid gap-3 sm:grid-cols-2">
            <input name="total_numbers" required inputMode="numeric" placeholder="Quantidade de números (1 a 10000)" className={inp} />
            <input name="price" required inputMode="decimal" placeholder="Valor por número em R$" className={inp} />
            <input name="participation_limit" inputMode="numeric" placeholder="Limite de números por pessoa" className={inp} />
            <span />
            <label className="text-sm">Início<input type="datetime-local" name="starts_at" className={inp} /></label>
            <label className="text-sm">Encerramento<input type="datetime-local" name="ends_at" className={inp} /></label>
          </div>
          <ImagePicker name="cover" label="Foto do prêmio (até 5 MB)" />
          {ehDono && (
            <div className="grid gap-2 rounded-2xl border border-[#7F8FFF44] p-3 text-sm">
              <label className="flex gap-2"><input type="checkbox" name="legal" /> Já tenho a autorização legal desta rifa (validação jurídica)</label>
              <label className="flex gap-2"><input type="checkbox" name="publicar" /> Publicar no site agora</label>
              <p className="text-xs text-[#9FB0E8]">Sem as duas marcações a rifa fica como rascunho e só você vê. Rifa só entra no ar com a validação jurídica marcada.</p>
            </div>)}
          <button className="rounded-xl bg-gradient-to-r from-[#7C5CFF] to-[#4F46E5] p-3 font-bold text-white">Salvar rascunho</button>
        </form>)}
    </main>
  );
}
