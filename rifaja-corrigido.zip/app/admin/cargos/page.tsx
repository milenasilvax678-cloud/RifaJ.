import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import AdminNav from "../nav";
import { criarCargo, excluirCargo, salvarPermissoes, adicionarAdmin, alterarCargoAdmin, revogarAcesso } from "./actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default async function Cargos({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("is_owner")).data) redirect("/admin"); // somente o dono

  const [roles, perms, rp, membros] = await Promise.all([
    supabase.from("roles").select("id,name,description,is_system").order("created_at"),
    supabase.from("permissions").select("key,description").order("key"),
    supabase.from("role_permissions").select("role_id,permission_key"),
    supabase.from("admin_members").select("user_id,role_id,revoked_at,created_at"),
  ]);
  const ids = (membros.data ?? []).map((m) => m.user_id);
  const { data: perfis } = ids.length ? await supabase.from("profiles").select("id,email,full_name").in("id", ids) : { data: [] };
  const R = roles.data ?? [];
  const atribuiveis = R.filter((r) => r.name !== "dono");
  const tem = (rid: string, k: string) => (rp.data ?? []).some((x) => x.role_id === rid && x.permission_key === k);
  const nomeCargo = (id: string) => R.find((r) => r.id === id)?.name ?? "?";

  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <h1 className="text-3xl font-extrabold">Cargos e administradores</h1>
      <p className="text-slate-600">Só o dono vê esta página. O cargo de dono não pode ser concedido por aqui.</p>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      <h2 className="mt-8 text-2xl font-bold">Administradores</h2>
      <form action={adicionarAdmin} className="mt-3 grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-[1fr_auto_auto]">
        <input name="email" type="email" required placeholder="E-mail de quem já tem conta" className={inp} />
        <select name="role_id" className="rounded-xl border p-3">{atribuiveis.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
        <button className="rounded-xl bg-[#1E5BFF] px-4 font-bold text-white">Adicionar</button>
      </form>
      <div className="mt-3 grid gap-3">
        {(membros.data ?? []).map((m) => {
          const p = perfis?.find((x) => x.id === m.user_id);
          const eDono = nomeCargo(m.role_id) === "dono";
          return (
            <div key={m.user_id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4">
              <div>
                <div className="font-bold">{p?.email ?? m.user_id}</div>
                <div className="text-sm text-slate-600">{nomeCargo(m.role_id)}{m.revoked_at ? " · acesso revogado" : ""}</div>
              </div>
              {!eDono && m.user_id !== user.id && (
                <div className="flex flex-wrap gap-2">
                  <form action={alterarCargoAdmin} className="flex gap-2">
                    <input type="hidden" name="user_id" value={m.user_id} />
                    <select name="role_id" defaultValue={m.role_id} className="rounded-lg border p-2">{atribuiveis.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
                    <button className="rounded-lg border px-3 font-bold">Trocar</button>
                  </form>
                  <form action={revogarAcesso}>
                    <input type="hidden" name="user_id" value={m.user_id} />
                    <input type="hidden" name="revogar" value={m.revoked_at ? "0" : "1"} />
                    <button className="rounded-lg bg-[#0A1B4D] px-3 py-2 font-bold text-white">{m.revoked_at ? "Restaurar" : "Revogar acesso"}</button>
                  </form>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <h2 className="mt-10 text-2xl font-bold">Cargos e permissões</h2>
      <form action={criarCargo} className="mt-3 grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-[1fr_2fr_auto]">
        <input name="name" required placeholder="Nome do cargo" className={inp} />
        <input name="description" placeholder="Descrição" className={inp} />
        <button className="rounded-xl bg-[#1E5BFF] px-4 py-3 font-bold text-white">Criar cargo</button>
      </form>
      <div className="mt-3 grid gap-4">
        {R.map((r) => (
          <section key={r.id} className="rounded-2xl border bg-white p-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-lg font-bold">{r.name} {r.is_system && <span className="text-xs font-normal text-slate-500">(padrão)</span>}</h3>
              {!r.is_system && (
                <form action={excluirCargo}><input type="hidden" name="role_id" value={r.id} />
                  <button className="rounded-lg border px-3 py-1 text-sm font-bold text-red-700">Excluir</button></form>
              )}
            </div>
            {r.description && <p className="text-sm text-slate-600">{r.description}</p>}
            {r.name === "dono" ? (
              <p className="mt-2 text-sm text-slate-600">Acesso total. Não editável.</p>
            ) : (
              <form action={salvarPermissoes} className="mt-3 grid gap-2">
                <input type="hidden" name="role_id" value={r.id} />
                <div className="grid gap-2 sm:grid-cols-2">
                  {(perms.data ?? []).map((p) => (
                    <label key={p.key} className="flex items-start gap-2 text-sm">
                      <input type="checkbox" name="perm" value={p.key} defaultChecked={tem(r.id, p.key)} className="mt-1" />
                      <span><b>{p.key}</b><br /><span className="text-slate-500">{p.description}</span></span>
                    </label>
                  ))}
                </div>
                <button className="mt-2 w-fit rounded-xl bg-[#0A1B4D] px-4 py-2 font-bold text-white">Salvar permissões</button>
              </form>
            )}
          </section>
        ))}
      </div>
    </main>
  );
}
