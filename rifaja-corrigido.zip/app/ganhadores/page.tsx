import { createClient } from "../../lib/supabase/server";
export const dynamic = "force-dynamic";
export default async function Ganhadores() {
  const supabase = await createClient();
  const { data } = await supabase.from("campaign_results").select("id,winner_name,announcement,proof_url,drawn_at,campaigns(name)").eq("published", true).order("created_at", { ascending: false });
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Ganhadores</h1>
      {data?.length ? <div className="mt-6 grid gap-4">{data.map((r: any) => (
        <article key={r.id} className="rounded-2xl border bg-white p-4">
          <span className="text-xs font-bold text-[#1E5BFF]">Resultado oficial{r.drawn_at ? ` · ${new Date(r.drawn_at + "T12:00").toLocaleDateString("pt-BR")}` : ""}</span>
          <h2 className="text-lg font-bold">{r.campaigns?.name}</h2>
          <p><b>Ganhador:</b> {r.winner_name}</p>
          {r.announcement && <p className="text-sm text-slate-600">{r.announcement}</p>}
          {r.proof_url && <a href={r.proof_url} target="_blank" rel="noopener noreferrer" className="text-sm font-bold text-[#1E5BFF] underline">Ver comprovante</a>}
        </article>))}</div>
        : <p className="mt-6 rounded-2xl border-2 border-dashed p-5 text-slate-600">Ainda não há resultados publicados. Não exibimos ganhadores de exemplo.</p>}
    </main>
  );
}
