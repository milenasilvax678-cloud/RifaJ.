// Chave de acesso ao painel: cookie assinado (HMAC) que só vale para o seu usuário e expira. Funciona no servidor e no middleware.
export const COOKIE_NAME = "rj_admin_gate";
const enc = new TextEncoder();

async function hmac(secret: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const s = await crypto.subtle.sign("HMAC", k, enc.encode(msg));
  return Array.from(new Uint8Array(s)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function igual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
export async function criarCookie(uid: string, segredo: string, horas = 8) {
  const base = `${uid}.${Date.now() + horas * 3600e3}`;
  return `${base}.${await hmac(segredo, base)}`;
}
export async function cookieValido(valor: string | undefined, uid: string, segredo?: string) {
  if (!valor || !segredo || segredo.length < 12) return false; // sem chave configurada, o painel fica fechado
  const [u, exp, sig] = valor.split(".");
  if (u !== uid || !exp || !sig || Number(exp) < Date.now()) return false;
  return igual(await hmac(segredo, `${u}.${exp}`), sig);
}
