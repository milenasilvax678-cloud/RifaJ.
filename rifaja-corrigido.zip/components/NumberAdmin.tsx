"use client";
import { useState } from "react";
import Link from "next/link";
import { useFormStatus } from "react-dom";
import { motion } from "motion/react";
import { editarNumeros } from "../app/admin/campanhas/[id]/numeros/actions";

type Info = { s: string; nome?: string | null; email?: string | null; pedido?: string | null };
const ROT: Record<string, string> = { livre: "Disponível", reservado: "Reservado (cliente pagando)", pago: "Pago", bloqueado: "Reservado pela equipe" };
const COR: Record<string, string> = {
  livre: "border-[#3B82F6] bg-[#1E3A8A]/60 text-white hover:bg-[#1E40AF]",
  reservado: "border-[#F59E0B] bg-[#F59E0B] text-black", pago: "border-[#22C55E] bg-[#22C55E] text-black", bloqueado: "border-[#8B5CF6] bg-[#8B5CF6] text-white",
};
const PAG = 100;

function Botoes({ podeEditar, podeVender }: { podeEditar: boolean; podeVender: boolean }) {
  const { pending } = useFormStatus();
  const b = "rounded-xl border-2 px-3 py-3 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-40 ";
  return (
    <div className="grid gap-2 sm:grid-cols-3">
      <button name="acao" value="liberar" disabled={pending || !podeEditar} className={b + "border-[#F87171] bg-[#F87171]/10 text-[#FCA5A5] hover:bg-[#F87171]/20"}>Liberar número</button>
      <button name="acao" value="bloquear" disabled={pending || !podeEditar} className={b + "border-[#F59E0B] bg-[#F59E0B]/10 text-[#FCD34D] hover:bg-[#F59E0B]/20"}>Reservar número</button>
      <button name="acao" value="vender_manual" disabled={pending || !podeVender} className={b + "border-[#22C55E] bg-[#22C55E]/10 text-[#86EFAC] hover:bg-[#22C55E]/20"}>{pending ? "Salvando…" : "Marcar como pago"}</button>
    </div>
  );
}

export default function NumberAdmin({ campaignId, total, mapa, podeEditar, podeVender }: { campaignId: string; total: number; mapa: Record<number, Info>; podeEditar: boolean; podeVender: boolean }) {
  const [sel, setSel] = useState<number[]>([]);
  const [pagina, setPagina] = useState(0);
  const paginas = Math.ceil(total / PAG), inicio = pagina * PAG + 1, fim = Math.min(total, inicio + PAG - 1);
  const alternar = (n: number) => setSel((s) => (s.includes(n) ? s.filter((x) => x !== n) : s.length >= 100 ? s : [...s, n]));
  const ordenados = [...sel].sort((a, b) => a - b);
  const um = ordenados.length === 1 ? mapa[ordenados[0]] ?? { s: "livre" } : null;
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap gap-2 text-xs font-bold" aria-label="Legenda">
        {["livre", "reservado", "pago", "bloqueado"].map((k) => <span key={k} className={`rounded-lg border-2 px-2.5 py-1 ${COR[k].split(" hover")[0]}`}>{ROT[k]}</span>)}
      </div>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(54px,1fr))] gap-2">
        {Array.from({ length: fim - inicio + 1 }, (_, i) => inicio + i).map((n) => {
          const st = mapa[n]?.s ?? "livre", on = sel.includes(n);
          return (
            <motion.button key={n} type="button" whileTap={{ scale: 0.88 }} onClick={() => alternar(n)} aria-pressed={on} aria-label={`Número ${n}, ${ROT[st]}`}
              className={`h-12 rounded-xl border-2 text-sm font-extrabold transition ${COR[st]} ${on ? "ring-2 ring-white ring-offset-2 ring-offset-[#0F1A55]" : ""}`}>{String(n).padStart(String(total).length, "0")}</motion.button>);
        })}
      </div>
      {paginas > 1 && (
        <div className="flex items-center justify-between text-sm">
          <button type="button" disabled={pagina === 0} onClick={() => setPagina(pagina - 1)} className="rounded-xl border px-4 py-2 font-bold disabled:opacity-40">Anterior</button>
          <span className="font-bold">{inicio}–{fim} de {total}</span>
          <button type="button" disabled={pagina >= paginas - 1} onClick={() => setPagina(pagina + 1)} className="rounded-xl border px-4 py-2 font-bold disabled:opacity-40">Próxima</button>
        </div>)}

      <div className="rounded-2xl border border-[#7F8FFF33] bg-white/5 p-3 text-sm">
        {!ordenados.length && <span className="text-[#9FB0E8]">Toque nos números para selecionar (até 100). Toque de novo para desmarcar.</span>}
        {ordenados.length > 0 && <p><b>{ordenados.length} selecionado(s):</b> {ordenados.join(", ")}</p>}
        {um && <p className="mt-1 text-[#C3D1FF]">Estado: <b>{ROT[um.s]}</b>{um.nome ? ` · ${um.nome}` : ""}{um.email ? ` · ${um.email}` : ""}
          {um.pedido && um.s !== "bloqueado" && <> · <Link href="/admin/pagamentos" className="font-bold text-[#8FB0FF] underline">abrir em Pagamentos</Link></>}</p>}
      </div>

      <form action={editarNumeros} className="grid gap-3">
        <input type="hidden" name="campaign_id" value={campaignId} />
        <input type="hidden" name="numbers" value={JSON.stringify(sel)} />
        {podeVender && (
          <label className="grid gap-1 text-sm">Justificativa para “Marcar como pago” (mínimo 15 caracteres; fica na auditoria)
            <textarea name="reason" rows={2} placeholder="Ex.: cliente pagou em dinheiro na entrega, combinado pelo WhatsApp" className="w-full rounded-xl border p-3" /></label>)}
        <Botoes podeEditar={podeEditar} podeVender={podeVender} />
        {!podeVender && <p className="text-xs text-[#9FB0E8]">Marcar como pago é venda manual: exige a permissão de confirmação manual (hoje, só o dono). Pagamentos de clientes são confirmados sozinhos pelo provedor.</p>}
      </form>
    </div>
  );
}
