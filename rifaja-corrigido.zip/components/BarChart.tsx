export default function BarChart({ dados }: { dados: { rotulo: string; valor: number }[] }) {
  if (!dados.length) return <p className="mt-6 rounded-xl border-2 border-dashed p-4 text-slate-600">Sem dados para o gráfico neste período.</p>;
  const max = Math.max(...dados.map((d) => d.valor));
  const w = Math.max(320, dados.length * 44);
  return (
    <div className="mt-6 overflow-x-auto rounded-2xl border bg-white p-4">
      <h2 className="mb-2 text-lg font-bold">Receita recebida por dia</h2>
      <svg viewBox={`0 0 ${w} 180`} width={w} height="180" role="img" aria-label="Receita recebida por dia">
        {dados.map((d, i) => {
          const h = Math.max(2, (d.valor / max) * 130);
          return (<g key={d.rotulo}>
            <rect x={i * 44 + 8} y={150 - h} width="28" height={h} rx="5" fill="#1E5BFF" />
            <text x={i * 44 + 22} y="168" textAnchor="middle" fontSize="11" fill="#56648C">{d.rotulo}</text>
          </g>);
        })}
      </svg>
    </div>
  );
}
