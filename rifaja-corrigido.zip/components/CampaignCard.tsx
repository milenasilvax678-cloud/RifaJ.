import Link from "next/link";
import { brl } from "../lib/periodo";
const NOMES: Record<string, string> = { free_fire: "Free Fire", roblox: "Roblox", outros: "Outros" };
type C = { slug: string; name: string; description: string | null; category: string | null; status: string; cover_url: string | null; price_cents?: number | null };
export default function CampaignCard({ c }: { c: C }) {
  return (
    <Link href={`/campanhas/${c.slug}`} className="overflow-hidden rounded-2xl border bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md">
      {c.cover_url
        // eslint-disable-next-line @next/next/no-img-element
        ? <img src={c.cover_url} alt={c.name} className="h-36 w-full object-cover" />
        : <div className="grid h-36 place-items-center bg-[#13286B] text-4xl font-extrabold text-white">{c.name.charAt(0)}</div>}
      <div className="grid gap-1 p-4">
        <span className="text-xs font-bold text-[#1E5BFF]">{c.category ?? "Rifa"}{c.status === "agendada" ? " · Em breve" : c.status === "encerrada" ? " · Encerrada" : ""}</span>
        <h3 className="text-lg font-bold">{c.name}</h3>
        <p className="line-clamp-2 text-sm text-slate-600">{c.description}</p>
        {c.price_cents != null && <p className="text-sm font-bold">{brl(c.price_cents)} por número</p>}
      </div>
    </Link>
  );
}
