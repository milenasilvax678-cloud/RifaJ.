"use client";
import { useFormStatus } from "react-dom";
export default function SubmitButton({ children, carregando = "Enviando…", className = "" }: { children: React.ReactNode; carregando?: string; className?: string }) {
  const { pending } = useFormStatus();
  return (
    <button disabled={pending} className={`flex items-center justify-center gap-2 rounded-xl bg-[#1E5BFF] px-4 py-3 font-bold text-white shadow-[0_0_18px_#1E5BFF55] disabled:opacity-60 ${className}`}>
      {pending && <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" aria-hidden="true" />}
      {pending ? carregando : children}
    </button>
  );
}
