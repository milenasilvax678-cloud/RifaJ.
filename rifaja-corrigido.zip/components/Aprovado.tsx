"use client";
import { motion } from "motion/react";
export default function Aprovado({ numeros }: { numeros: number[] }) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: "spring", stiffness: 220, damping: 18 }}
      className="mt-4 rounded-2xl border border-green-300 bg-green-50 p-5 text-center">
      <motion.svg width="56" height="56" viewBox="0 0 56 56" className="mx-auto" aria-hidden="true">
        <circle cx="28" cy="28" r="26" fill="#16A34A" />
        <motion.path d="M16 29l8 8 16-17" stroke="#fff" strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 0.2, duration: 0.5 }} />
      </motion.svg>
      <h2 className="mt-3 text-2xl font-extrabold text-green-900">Pagamento aprovado!</h2>
      <p className="mt-1 text-green-900">Seus números: <b>{numeros.join(", ")}</b></p>
    </motion.div>
  );
}
