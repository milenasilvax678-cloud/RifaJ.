import { STATUS } from "../lib/suporte";
export default function StatusBadge({ status }: { status: string }) {
  const s = STATUS[status] ?? { rot: status, cls: "bg-slate-200 text-slate-700" };
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${s.cls}`}>{s.rot}</span>;
}
