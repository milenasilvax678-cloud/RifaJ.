"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import Logo from "./Logo";
import SocialIcon, { NOME_REDE } from "./SocialIcon";
import type { Rede } from "../lib/social";

const itens = [
  ["Início", "/"], ["Campanhas", "/campanhas"], ["Promoções", "/#promocoes"], ["Como funciona", "/#como"],
  ["Ganhadores", "/ganhadores"], ["Suporte", "/suporte"], ["Indique amigos", "/conta#indicacao"], ["Minha conta", "/conta"], ["Central de ajuda", "/suporte#faq"],
];
export default function Menu({ redes, admin }: { redes: Rede[]; admin?: boolean }) {
  const [aberto, setAberto] = useState(false);
  useEffect(() => {
    const f = (e: KeyboardEvent) => e.key === "Escape" && setAberto(false);
    window.addEventListener("keydown", f);
    return () => window.removeEventListener("keydown", f);
  }, []);
  return (
    <>
      <button aria-label="Abrir menu" aria-expanded={aberto} onClick={() => setAberto(true)} className="grid h-11 w-11 place-items-center rounded-lg">
        <span className="block h-0.5 w-5 bg-white shadow-[0_7px_0_#fff,0_-7px_0_#fff]" />
      </button>
      <AnimatePresence>
        {aberto && (
          <>
            <motion.div key="v" className="fixed inset-0 z-40 bg-black/60" onClick={() => setAberto(false)} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />
            <motion.nav key="d" aria-label="Menu principal" className="fixed inset-y-0 left-0 z-50 w-[min(320px,86vw)] overflow-auto bg-[#0A1B4D] p-5 text-white"
              initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }} transition={{ type: "tween", duration: 0.25 }}>
              <div className="mb-4"><Logo /></div>
              {admin && <Link href="/admin" onClick={() => setAberto(false)} className="mb-2 block rounded-lg bg-gradient-to-r from-[#4F46E5] to-[#2D6BFF] px-3 py-3 font-bold">Painel administrativo</Link>}
              {itens.map(([t, h]) => <Link key={t} href={h} onClick={() => setAberto(false)} className="block rounded-lg px-3 py-3 font-medium hover:bg-[#13286B]">{t}</Link>)}
              {redes.length > 0 && <hr className="my-3 border-white/20" />}
              {redes.map((r) => (
                <a key={r.network} href={r.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-lg px-3 py-3 hover:bg-[#13286B]">
                  <span className="grid h-7 w-7 place-items-center rounded-md bg-white text-[#0A1B4D]"><SocialIcon network={r.network} size={16} /></span>{NOME_REDE[r.network]}
                </a>))}
            </motion.nav>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
